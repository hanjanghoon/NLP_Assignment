
class Node():
    def __init__(self, syllable='start'):
        self.syllable = syllable
        self.morph = []
        self.sibling = None
        self.parent = None
        self.child = None
        self.leaf = 0
        self.visited = 0

def insert(head, word_morph):
    head_copy = head
    word = word_morph.split('/')[0]
    morph = word_morph.split('/')[1]
    for i, syllable in enumerate(word):
       # print(i,syllable)
        if head.child is None:
            target_node = Node(syllable)
            head.child = target_node
        else:
            target_node = set_sibling(head.child, syllable)
        if i is len(word)-1:
            target_node.leaf=1
            if morph not in target_node.morph:
                target_node.morph.append(morph)
            break
        head = target_node
    head = head_copy

def set_sibling(head, syllable):
    tmp = head
    #print(tmp.syllable, syllable)
    target_node = None
    while True:
        if tmp.syllable == syllable:#똑같은 음절이 있으면
            return tmp#걍 그대로
        if tmp.sibling is None:# 다 봤는데 없으면 새로만듬
            tmp.sibling = Node(syllable)
            return tmp.sibling
        tmp=tmp.sibling# 다르면 다음거 봄

def parse_sentence(sentence):
    word_list = []
    for word in sentence.replace('\n','').replace('+',' ').split(' '):
        word_list.append(word)
    return word_list

def check_word_in_dictionary(head, word):
    head_copy = head
    for i, syllable in enumerate(word):
        if head is None:
            return None
        target_node = find_sibling(head.child, syllable)
        if target_node is None:
            return None
        head = target_node
    head = head_copy
    if target_node.leaf == 1:
        return target_node
    return None

def make_dictionary_TRIE(input_name='manual_tagging.txt', output_name='dictionary.txt'):
    fr = open(input_name,'r')
    fw = open(output_name,'w')
    stacklist = []
    HEAD = Node()
    for sentence in fr.readlines():
        words = parse_sentence(sentence)
        for word in words:
            insert(HEAD, word)
    print_dict(HEAD.child, stacklist, fw)
    fr.close()
    fw.close()
    return HEAD, stacklist


def find_sibling(head, syllable):
    tmp = head
    target_node = None
    while True:
        if tmp is None:
            return None
        if tmp.syllable == syllable:
            return tmp
        tmp = tmp.sibling


def print_dict(head_copy, stack, fp):
    cnt=0
    if head_copy is not None:
        if head_copy.syllable != 'start':
            stack.append(head_copy.syllable)
        if head_copy.visited == 0 and head_copy.leaf == 1:
            for syllable in stack:
                fp.write(syllable)
                cnt=cnt+1
                fp.write(str(cnt))
            fp.write(" / ")
            for morph in head_copy.morph:
                fp.write("["+morph+"]")
            fp.write('\n')
            head_copy.visited = 1
        print_dict(head_copy.child, stack, fp)
        stack.pop()
        print_dict(head_copy.sibling, stack, fp)
