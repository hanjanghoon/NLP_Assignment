def grammar_parser(string):
    grammarlist=[]
    for word in string.replace('\n','').split(' '):
        grammarlist.append(word)
   # print(wordlist)
    return grammarlist

def origin_parser(string):
    wordlist = []
    for word in string.replace('\n','').split(' '):
        wordlist.append(word)
    return wordlist

def get_grammar_manual(file_name1='manual_tagging.txt',file_name2='original.txt',file_name3='grammar.txt'):
    grammarlist=[]
    wordlist = []
    f1 = open(file_name1,'r')
    f2 = open(file_name2, 'r')
    f3 = open(file_name3, 'w')
    for sentence in f1.readlines():
        grammars = grammar_parser(sentence)
        grammarlist+=grammars
        #print(words)
    for sentence in f2.readlines():
        words = origin_parser(sentence)
        wordlist += words
        # print(words)
    for i in range(len(wordlist)):
        f3.write(wordlist[i]+"\t"+grammarlist[i]+'\n')
    f1.close()
    f2.close()
    f3.close()
    return grammarlist


if __name__ == '__main__':
    grammarlist=[]
    grammarlist = get_grammar_manual()
    #print(grammarlist)