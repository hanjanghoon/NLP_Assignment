import dictionary_TRIE


class Cell():
    def __init__(self):
         self.morphs = []


def taboular_parse(word, HEAD, grammar_list):
    length = len(word)
    #print(word)
    #print("~~~~~~")

    cell_list = []
    for i in range(length):
        tmp_list = []
        for j in range(length):
            tmp_list.append(Cell())
        cell_list.append(tmp_list)


    for i in reversed(range(length)):#단어길이 끝부터 감.
        for j in range(length - i):#이건 정자로 감
            sliced_word = word[i:i+j+1] #단어 자르기
            #print(sliced_word)
            word_morph = dictionary_TRIE.check_word_in_dictionary(HEAD, sliced_word)#사전에 있는지확인
            #print(i, j)
            if word_morph is not None:
                #print("!!!"+sliced_word+"!!!") #사전에 있는거 들어감.
                for morph in word_morph.morph:#동사 명사
                    cell_list[i][j].morphs.append(sliced_word+'/'+morph)


                if (i+j) != (length-1):
                    index = length-(i+j)-2
                #    print("1번",i,j,)
                    for m2 in cell_list[length-1-index][index].morphs:
                        for m1 in cell_list[i][j].morphs:
                            #print("lala",m1, m2)
                            grammar_tmp = m1 + '+' +m2
                            for gram in grammar_list:
                                if grammar_tmp in gram and grammar_tmp not in (cell_list[i][length - 1 - i].morphs) :
                                   # print(grammar_tmp,gram)
                                    cell_list[i][length - 1 - i].morphs.append(grammar_tmp)
    return cell_list[0][length-1]

if __name__ == '__main__':
    HEAD, stack = dictionary_TRIE.make_dictionary_TRIE()
    grammarlist = [];
    fg = open('grammar.txt','r')
    for line in fg.readlines():
        grammarlist.append(line.split('\t')[1])
    fi = open('original.txt','r')
    fo = open('output.txt','w')
    for line in fi.readlines():
        for word in line.split():
            cell = taboular_parse(word,HEAD, grammarlist)
            for m in cell.morphs:#형태소가 여러개일 경우 다 출력
                fo.write(m)
            fo.write(' ')
        fo.write('\n')
    fi.close()
    fo.close()
    fg.close()


